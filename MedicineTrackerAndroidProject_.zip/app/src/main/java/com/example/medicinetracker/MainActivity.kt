package com.example.medicinetracker

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Dose(val id: Int, val name: String, val slot: String, val hour: Int, val minute: Int)
data class Record(val doseId: Int, val name: String, val slot: String, val date: String, val status: String)

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("medicine_data", MODE_PRIVATE) }
    private fun dateKey() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun loadDoses(): List<Dose> {
        val a = JSONArray(prefs.getString("doses", "[]"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); Dose(o.getInt("id"),o.getString("name"),o.getString("slot"),o.getInt("hour"),o.getInt("minute")) }
    }
    private fun saveDoses(list: List<Dose>) {
        val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("slot",it.slot).put("hour",it.hour).put("minute",it.minute)) }
        prefs.edit().putString("doses",a.toString()).apply()
    }
    private fun loadRecords(): List<Record> {
        val a=JSONArray(prefs.getString("records","[]"))
        return (0 until a.length()).map { val o=a.getJSONObject(it); Record(o.getInt("doseId"),o.getString("name"),o.getString("slot"),o.getString("date"),o.getString("status")) }
    }
    private fun saveRecords(list: List<Record>) {
        val a=JSONArray(); list.forEach { a.put(JSONObject().put("doseId",it.doseId).put("name",it.name).put("slot",it.slot).put("date",it.date).put("status",it.status)) }
        prefs.edit().putString("records",a.toString()).apply()
    }
    private fun schedule(d: Dose) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("medicine",d.name).putExtra("slot",d.slot).putExtra("id",d.id)
        val pi = PendingIntent.getBroadcast(this,d.id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val c=Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY,d.hour); set(Calendar.MINUTE,d.minute); set(Calendar.SECOND,0); set(Calendar.MILLISECOND,0); if(timeInMillis<=System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR,1) }
        if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi) else alarm.setExact(AlarmManager.RTC_WAKEUP,c.timeInMillis,pi)
    }
    private fun scheduleAll() = loadDoses().forEach { schedule(it) }

    private fun cancelReminder(d: Dose) {
        val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            this, d.id, intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pi != null) {
            alarm.cancel(pi)
            pi.cancel()
        }
        // Also dismiss a reminder notification that may already be visible.
        val notifications = getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        notifications.cancel(d.id)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 100)
        setContent { TrackerScreen() }
        scheduleAll()
    }

    @Composable fun TrackerScreen() {
        var doses by remember { mutableStateOf(loadDoses()) }
        var records by remember { mutableStateOf(loadRecords()) }
        var showAdd by remember { mutableStateOf(false) }
        var dosePendingDelete by remember { mutableStateOf<Dose?>(null) }
        var history by remember { mutableStateOf(false) }
        var name by remember { mutableStateOf("") }
        var slot by remember { mutableStateOf("Morning") }
        var time by remember { mutableStateOf("08:00") }
        val today=dateKey()
        // Mark any unchecked dose as missed after its scheduled time.
        LaunchedEffect(doses, records, today) {
            var changed=false
            val updated=records.toMutableList()
            doses.forEach { d ->
                if (updated.none { it.doseId==d.id && it.date==today }) {
                    val now=Calendar.getInstance()
                    val passed=now.get(Calendar.HOUR_OF_DAY)*60+now.get(Calendar.MINUTE) >= d.hour*60+d.minute
                    if(passed) { updated.add(Record(d.id,d.name,d.slot,today,"Missed")); changed=true }
                }
            }
            if(changed) { saveRecords(updated); records=updated }
        }
        fun mark(d: Dose, status: String) {
            val next=records.filterNot { it.doseId==d.id && it.date==today } + Record(d.id,d.name,d.slot,today,status)
            records=next; saveRecords(next)
        }
        MaterialTheme {
            Scaffold(topBar={ TopAppBarCompat(title="💊 Medicine Tracker", action={ TextButton(onClick={history=!history}) { Text(if(history) "Today" else "History") } }) }) { pad ->
                Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
                    if(!history) {
                        val done=records.count { it.date==today && it.status=="Taken" }
                        Text("Today's progress: $done / ${doses.size}", style=MaterialTheme.typography.titleLarge)
                        LinearProgressIndicator(progress={ if(doses.isEmpty()) 0f else done.toFloat()/doses.size }, modifier=Modifier.fillMaxWidth().padding(vertical=10.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.End) { Button(onClick={showAdd=true}) { Text("+ Add medicine") } }
                        if(doses.isEmpty()) Text("No medicines yet. Add your first medicine.")
                        LazyColumn { items(doses, key={it.id}) { d ->
                            val status=records.firstOrNull { it.doseId==d.id && it.date==today }?.status ?: "Not marked"
                            Card(Modifier.fillMaxWidth().padding(vertical=5.dp)) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(d.name, style=MaterialTheme.typography.titleMedium)
                                    Text("${d.slot} • ${"%02d:%02d".format(d.hour,d.minute)}")
                                    Text("Status: $status")
                                    Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
                                        Button(onClick={mark(d,"Taken")}, enabled=status!="Taken") { Text("✓ Taken") }
                                        OutlinedButton(onClick={mark(d,"Missed")}, enabled=status!="Missed") { Text("Missed") }
                                        OutlinedButton(onClick={dosePendingDelete=d}) { Text("Delete") }
                                    }
                                }
                            }
                        } }
                    } else {
                        Text("Previous days", style=MaterialTheme.typography.titleLarge)
                        val grouped=records.sortedByDescending { it.date }.groupBy { it.date }
                        if(grouped.isEmpty()) Text("No history recorded yet.")
                        LazyColumn { grouped.forEach { (day, rows) ->
                            item { Text(day, style=MaterialTheme.typography.titleMedium, modifier=Modifier.padding(top=12.dp)) }
                            items(rows) { r -> Text("${r.name} • ${r.slot}: ${r.status}", modifier=Modifier.padding(vertical=4.dp)) }
                        } }
                    }
                }
            }
            dosePendingDelete?.let { dose ->
                AlertDialog(
                    onDismissRequest={dosePendingDelete=null},
                    title={Text("Delete medicine?")},
                    text={Text("Remove ${dose.name} from your medicine list? Its scheduled reminder will be cancelled. Existing history will be kept.")},
                    confirmButton={
                        TextButton(onClick={
                            cancelReminder(dose)
                            doses=doses.filterNot { it.id==dose.id }
                            saveDoses(doses)
                            dosePendingDelete=null
                        }) { Text("Delete") }
                    },
                    dismissButton={
                        TextButton(onClick={dosePendingDelete=null}) { Text("Cancel") }
                    }
                )
            }
            if(showAdd) AlertDialog(
                onDismissRequest={showAdd=false},
                title={Text("Add medicine")},
                text={
                    Column(verticalArrangement=Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name,{name=it},label={Text("Medicine name")},singleLine=true)
                        Text("Schedule")
                        Row(horizontalArrangement=Arrangement.spacedBy(4.dp)) {
                            listOf("Morning","Afternoon","Night").forEach { s -> FilterChip(selected=slot==s,onClick={slot=s},label={Text(s)}) }
                        }
                        OutlinedTextField(time,{time=it},label={Text("Reminder time (24-hour HH:mm)")},singleLine=true)
                    }
                },
                confirmButton={ TextButton(onClick={
                    val parts=time.split(":")
                    val h=parts.getOrNull(0)?.toIntOrNull(); val m=parts.getOrNull(1)?.toIntOrNull()
                    if(name.isNotBlank() && h!=null && m!=null && h in 0..23 && m in 0..59) {
                        val d=Dose((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),name.trim(),slot,h,m)
                        doses=doses+d; saveDoses(doses); schedule(d); name=""; time="08:00"; showAdd=false
                    }
                }) { Text("Save") } },
                dismissButton={ TextButton(onClick={showAdd=false}) { Text("Cancel") } }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun TopAppBarCompat(title: String, action: @Composable () -> Unit) {
    TopAppBar(title={Text(title)}, actions={action()})
}
