package com.example.medicinetracker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val channel = "medicine_reminders"
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel(channel, "Medicine reminders", NotificationManager.IMPORTANCE_HIGH))
        }
        val med = intent.getStringExtra("medicine") ?: "Your medicine"
        val slot = intent.getStringExtra("slot") ?: ""
        val notification = NotificationCompat.Builder(context, channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Medicine reminder")
            .setContentText("Time to take $med ($slot). Mark it in Medicine Tracker.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true).build()
        manager.notify(intent.getIntExtra("id", 1), notification)
    }
}
