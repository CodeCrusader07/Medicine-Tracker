# Medicine Tracker Android project

## Build an APK
1. Install Android Studio (stable version) on a computer.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components (compile SDK 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio shows a link to the generated APK (usually app/build/outputs/apk/debug/app-debug.apk).
6. Transfer the APK to your Android phone and install it. You may need to allow installation from that source.

## Features
- Add medicines with Morning / Afternoon / Night labels and a 24-hour reminder time.
- Daily Taken / Missed checklist.
- Previous-days history stored locally on the phone.
- Reminder notifications (allow notifications when prompted).\n- Delete medicines with confirmation; their pending alarms and visible notifications are cancelled. Existing history is retained.

## Important notes
- This is a starter project, not a medically validated medication system.
- Android may restrict exact alarms or background delivery depending on device settings and OS version. If reminders do not arrive, enable notifications and allow alarms/reminders for the app in Android settings.
- Current reminder scheduling sets the next alarm; it is rescheduled when the app is opened. Open the app after a phone restart to re-establish alarms.
- Missed status is automatically recorded when you open the app after a scheduled dose time and no status was recorded. Marking Taken/Missed manually overrides that day's status.
- The app does not recommend doses. Enter only the medicine schedule prescribed by your clinician/pharmacist. Do not change or double a dose based on app status.

## Build using only your Android phone (GitHub Actions)
This project includes `.github/workflows/build-apk.yml` so GitHub can build the APK in the cloud.
1. In your phone browser, sign in to GitHub and create a new repository.
2. Upload the *contents* of this ZIP (including the hidden `.github` folder; if your file manager hides it, use GitHub's web upload or a ZIP-aware uploader that preserves hidden folders).
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. Select **Build Android APK**, then **Run workflow** if it has not started automatically.
5. Wait for the workflow to finish successfully. Open the completed run and download the `medicine-tracker-debug-apk` artifact.
6. Extract the downloaded artifact ZIP; tap `app-debug.apk` to install. Android may ask you to allow installs from your browser or file manager.

The APK is a debug build for personal testing, not a Play Store release.


### Application icon
The launcher icon now uses the supplied Medicine Tracker logo artwork in density-specific launcher resources and the Android adaptive icon foreground.
